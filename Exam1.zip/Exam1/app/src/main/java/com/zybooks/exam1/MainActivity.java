package com.zybooks.exam1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

    public class MainActivity extends AppCompatActivity {
        //Mykayla Vallad
        //ISYS 221-VL2
        //Exam 1
        //Due 09/19/21

        Button openLink;
        Button aboutUs;
        EditText inputCelsuis;
        Button convert;
        Context context;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            context=this;
            // this button used to navigate the user to about us screen
            aboutUs = (Button)findViewById(R.id.About_Us);
            aboutUs.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Intent used to navigate the user to Main Activity 2
                    Intent i = new Intent(context, MainActivity2.class);
                    // start the Main Activity 2
                    startActivity(i);
                }
            });
            // this button is used to open to link that you provide
            openLink = (Button)findViewById(R.id.Link);
            openLink.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Uri uri = Uri.parse("paste_our_link_here");
                    // this intent open the link in browser
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    // open the link
                    startActivity(intent);
                }
            });
            // convert button is used to convert the temperate to fahrenheit
            // formula = c*1.8+32
            inputCelsuis = (EditText) findViewById(R.id.Input_Celsuis);
            convert = (Button)findViewById(R.id.Convert);
            convert.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    // caculate the temperate in fahrenheit
                    // and store in res variable
                    double res=Integer.parseInt(inputCelsuis.getText().toString())*1.8+32;
                    // show toast of temperate in fahrenheit
                    Toast.makeText(context, "Temperature in Fahrenheit : "+res,
                            Toast.LENGTH_LONG).show();
                }

            });


        }
    }
